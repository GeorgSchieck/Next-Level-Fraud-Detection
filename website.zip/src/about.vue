<template>
  <div id="about">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-12">
          <h3 class="section-title">About Us</h3>
          <div class="section-title-divider"></div>
          <p class="section-description">Football if life!</p>
        </div>
      </div>
    </div>
    <div class="container about-container wow fadeInUp">
      <div class="row">
        <div class="col-md-6 col-md-push-6 about-content">
          <h2 class="about-title">We provide great Football Data</h2>
          <p class="about-text">
            Football Database is a small team of individually skilled Data Scientists coming from all different backgrounds. Using those skills and working as an agile Team, we have built our expertise working with big and small clients in various Data Science fields.
          </p>
          <p class="about-text">
            Our mission is to bring the most important topic of our time - Football - closer to you. Our solutions will advance your Gambling and make you more competitive.
          </p>
          <p class="about-text">
            Applying newest technology such as machine learning and data mining, while considering trends and changes in the market makes us the best in our field.
            Combining our data science expertise and your domain knowledge, we can make you the best in yours!
          </p>

        </div>
      </div>
    </div>
  </div>
</template>
<style>
  #about {
    min-height: 100vh;
  }
</style>
