<template>
  <div id="datenschutz">
    <div class="container wow fadeInUp">
      <h1>Datenschutz</h1>
    </div>
  </div>
</template>
<style>
  #datenschutz {
    min-height: 100vh;
  }
</style>
