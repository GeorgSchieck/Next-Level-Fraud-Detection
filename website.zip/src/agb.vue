<template>
  <div id="agb">
    <div class="container wow fadeInUp">
      <h1>Allgmeine Geschätsbedingungen</h1>
    </div>
  </div>
</template>
<style>
  #agb {
    min-height: 100vh;
  }
</style>
