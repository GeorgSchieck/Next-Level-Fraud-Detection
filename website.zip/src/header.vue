<template>
  <header id="header">
    <div class="container-fluid">

      <div id="logo" class="pull-left">
        <!--<a href="#hero"><img src="img/logo.png" alt="" title="" /></img></a>-->
        <!-- Uncomment below if you prefer to use a text image -->
        <h1>
          <router-link class="btn-services" to="/" tag="a">
            Fraud Detection
          </router-link>
        </h1>
      </div>


      <!-- #nav-menu-container -->
    </div>
  </header>
</template>


