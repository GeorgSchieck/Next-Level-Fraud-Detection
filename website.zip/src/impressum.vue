<template>
  <div id="impressum">
    <div class="container wow fadeInUp">
      <h1>Impressum</h1>
    </div>
  </div>
</template>
<style>
  #impressum {
    min-height: 100vh;
  }
</style>
